import os

file_dir = os.path.dirname(__file__)
all_future = os.path.join(file_dir, 'all_feature.csv')
all_meetings = os.path.join(file_dir, 'all_meetings.csv')
meeting_data = os.path.join(file_dir, 'meeting_data.csv')
user_data = os.path.join(file_dir, 'user_data.csv')

config = {'host': '127.0.0.1',
          'port': 3306,
          'user': 'root',
          'password': 'qianjiale19980',
          'db': 'computer',
          'charset': 'utf8',
          }

engine_config = "mysql+pymysql://root:qianjiale19980@localhost:3306/computer?charset=utf8"


