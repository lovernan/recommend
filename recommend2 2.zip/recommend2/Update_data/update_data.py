import pandas as pd
import pymysql
from sqlalchemy import create_engine
from file import *


class Update_data(object):

    def __init__(self, table_name):

        self.table_name = table_name

        self.config = config

        db = pymysql.connect(**self.config)
        self.cursor = db.cursor()
        self.index = self.get_index()

        def mysql_connect():
            engine = create_engine(engine_config)
            return engine

        mysql_connect()

    def get_meeting_col(self):
        self.cursor.execute("select * from %s" % self.table_name)
        col_name_list = [tuple[0] for tuple in self.cursor.description]
        return col_name_list

    def get_pd(self):

        sql = "select * from {} ".format(self.table_name)
        self.cursor.execute(sql)
        alist = self.cursor.fetchall()

        result = []
        for i in alist:
            result.append(list(i))
        cols = []
        for i in self.get_meeting_col():
            cols.append(i[0])
        return pd.DataFrame(result,
                            columns=cols)

    def get_index(self):
        sql = "select * from {} ".format(self.table_name)
        self.cursor.execute(sql)
        alist = self.cursor.fetchall()
        index = []
        for i in alist:
            index.append(i[0])
        return index


if __name__ == '__main__':
    T = Update_data('user_history')
    print(T.get_pd())