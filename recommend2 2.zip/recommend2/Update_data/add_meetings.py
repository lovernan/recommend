import pandas as pd
import pymysql
from sqlalchemy import create_engine
from file import *


class AddMeetings(object):

    def __init__(self, table_name):

        self.table_name = table_name
        self.config = config

        db = pymysql.connect(**self.config)
        self.cursor = db.cursor()

        def mysql_connect():
            engine = create_engine(engine_config)
            return engine

        self.engine = mysql_connect()
        self.meetings = []
        self.features = self.meeting_feature()


    def meeting_feature(self):

        sql = "select * from {}".format(self.table_name)
        self.cursor.execute(sql)
        alist = self.cursor.fetchall()
        # return alist[0][10:13]
        meeting_id = []
        f1 = []
        f2 = []
        f3 = []
        for record in alist:
            self.meetings.append(int(record[0]))
            meeting_id.append(int(record[0]))
            f1.append(int(record[10]))
            f2.append(int(record[11]))
            f3.append(int(record[12]))
        dict = {'mid': meeting_id,
                'f1': f1,
                'f2': f2,
                'f3': f3}
        df = pd.DataFrame(dict)

        return df

    def update_feature_table(self):
        df1 = self.meeting_feature()
        records = []
        for row in df1.values:
            per_record = []
            per_record.append(row[0])
            for i in range(16):
                per_record.append(0)
            for index in row[1:]:
                per_record[index+1] = 1
            records.append(per_record)
        df2 = pd.DataFrame(records)
        pd.io.sql.to_sql(df2, 'meeting_feature2', self.engine, schema='computer', if_exists='append', index=False,
                         index_label=False)


if __name__ == '__main__':
    A = AddMeetings('meeting')
    A.update_feature_table()