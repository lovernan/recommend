#!/usr/bin/python
# -*- coding: UTF-8 -*-
import pymysql
from file import *

class InsertRecommend():

    def __init__(self, list):

        self.list = list
        main_config = config

        self.db = pymysql.connect(**main_config)
        self.cursor = self.db.cursor()

    def insert_meeting(self):

        sql = """INSERT INTO user_recommend 
                 VALUES ({},{},{},{},{},{})""".format(self.list[0], self.list[1], self.list[2],
                                                      self.list[3], self.list[4], self.list[5])

        self.cursor.execute(sql)
        self.db.commit()

if __name__ == '__main__':
    I = InsertRecommend([100, 2, 3, 4, 5, 6])
    I.insert_meeting()


