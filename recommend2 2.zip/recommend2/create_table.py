import pymysql
import numpy as np
import pandas as pd
from sqlalchemy.engine import create_engine
from file import *
from Update_data.add_meetings import AddMeetings
import random

main_config = engine_config


class Create(object):

    def __init__(self):

        self.db = pymysql.connect(**config)
        self.cursor = self.db.cursor()

    def create_info(self, data, table_name, ):

        table_name = table_name
        engine = create_engine(main_config)
        pd.io.sql.to_sql(data, table_name, engine, schema='computer', if_exists='append', index=False,
                         index_label=False)


if __name__ == '__main__':

    C = Create()

    def create_user_history():
        cols = ['user_id']
        cols.extend(list(range(3)))
        user_meeting = pd.DataFrame(np.empty((100, 4)),
                                    columns=cols)
        A = AddMeetings('meeting')
        for i in range(len(user_meeting.index)):
            for j in range(len(user_meeting.columns)):
                random_num = random.randint(0, len(A.meetings)-1)
                user_meeting.iloc[i, j] = A.meetings[random_num]
        for i in range(len(user_meeting.index)):
            user_meeting.iloc[i, 0] = i
        C.create_info(user_meeting, 'user_history')
        print('user_history has been created!')


    def create_meeting_feature():
        C.create_info(pd.read_csv(meeting_data), 'meeting_feature')
        print('meeting_feature has been created!')

    def create_user_meeting():
        C.create_info(pd.read_csv(user_data), 'user_meeting')
        print('user_meeting has been created!')

    def create_user_recommend():

        cols = []
        cols.extend(list(range(6)))
        user_recommend = pd.DataFrame(columns=cols)

        for i in range(len(user_recommend)):
            user_recommend.iloc[i, 0] = i
        C.create_info(user_recommend, 'user_recommend')
        print('user_recommend has been created!')


    create_user_history()
    # create_meeting_feature()
    # create_user_recommend()

