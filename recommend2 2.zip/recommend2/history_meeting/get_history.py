import pandas as pd
import pymysql
from sqlalchemy import create_engine
from file import *


class HistoryMeeting(object):

    def __init__(self, table_name, user_id):

        self.user_id =user_id
        self.table_name = table_name

        self.config = config

        db = pymysql.connect(**self.config)
        self.cursor = db.cursor()

        def mysql_connect():
            engine = create_engine(engine_config)
            return engine

        mysql_connect()

    def get_meeting_id(self):

        sql = "select * from {} WHERE user_id={}".format(self.table_name, self.user_id)
        self.cursor.execute(sql)
        alist = self.cursor.fetchall()
        return alist[0][1:]


if __name__ == '__main__':
    T = HistoryMeeting('user_history', 99)
    print(T.get_meeting_id())