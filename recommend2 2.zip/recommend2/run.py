# encoding: utf-8
import time
import pandas as pd
import numpy as np
import operator
import pymysql
from sqlalchemy import create_engine
from Update_data.update_data import Update_data
from file import *
# from create_table.create_table import Create
from history_meeting.get_history import HistoryMeeting
from insert_data.recommend import InsertRecommend
from Update_data.add_meetings import AddMeetings

main_config = config


class Recommend(object):

    def __init__(self, kind,  user_id, k=5,):
        self.kind = kind
        self.k = k
        self.user_id = user_id
        self.id_list = self.history_id()
        self.pd = None
        if not kind:
            print('data not exist!')
            return
        self.array_2 = self.read_data()

    def read_data(self):

        file = Update_data(self.kind).get_pd()
        self.pd = file
        value = file.values
        return value

    def cal_distance(self, list1, list2):
        sum = 0
        for i in range(len(list1) - 2):
            sum += abs(list1[i] - list2[i])
        sum += 2*abs(list1[-1] - list2[-1])
        sum += 3*abs(list1[-2] - list2[-2])
        sum += 2*abs(list1[-3] - list2[-3])
        sum += 2*abs(list1[-6] - list2[-6])
        sum += 2*abs(list1[5] - list2[5])
        return sum

    def history_id(self):
        return HistoryMeeting('user_history', self.user_id).get_meeting_id()

    def get_result(self,):

        distance_dict = {}
        mid = []
        for meeting in self.array_2:
            mid.append(meeting[0])
        distance_dict = {}

        for meeting_id in mid:
            sum = 0
            m_id = mid.index(meeting_id)
            for history_id in self.id_list:
                history_id = int(history_id)
                if not history_id == meeting_id:
                    h_index = mid.index(history_id)
                    dist = self.cal_distance(self.array_2[h_index][1:], self.array_2[m_id][1:])
                    sum += dist
            distance_dict[str(meeting_id)] = sum
        sorted_dict = sorted(distance_dict.items(), key=lambda item: item[1])
        recommend_list = []
        for i in sorted_dict[0:self.k]:
            recommend_list.append(i[0])
        # for i in recommend_list:
        #     print(self.array_2[int(i)])
        # insert_data = [self.user_id]
        # insert_data.extend([int(i) for i in recommend_list])
        # InsertRecommend(insert_data).insert_meeting()
        return recommend_list

    def insert_data(self):
        recommend_list = self.get_result()
        insert_data = [int(self.user_id)]
        insert_data.extend([int(i) for i in recommend_list])
        InsertRecommend(insert_data).insert_meeting()


def clean():

    db = pymysql.connect(**main_config)
    cursor = db.cursor()
    sql1 = '''truncate user_recommend'''
    sql2 = '''truncate meeting_feature2'''
    cursor.execute(sql1)
    cursor.execute(sql2)
    db.commit()


if __name__ == '__main__':

    # 创建Table
    # C = Create()
    # C.create_info(user_data, 'user_info')
    # C.create_info(meeting_data, 'meeting_info')
    start_time = time.time()
    clean()
    A = AddMeetings('meeting')
    A.update_feature_table()

    for i in Update_data('user_history').get_index():
        R = Recommend('meeting_feature2', i)
        R.insert_data()
    end_time = time.time()
    print('completed!')
    print('use time:{}s'.format(end_time - start_time))




